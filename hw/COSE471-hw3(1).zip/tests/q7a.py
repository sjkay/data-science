test = {   'name': 'q7a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(linear_model, '
                                               'lm.LinearRegression)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'linear_model.fit_intercept\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
