test = {   'name': 'q7b',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> 179000 <= y_fitted.mean() '
                                               '<= 180000\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> 188000 <= '
                                               'y_predicted.mean() <= 190000\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
