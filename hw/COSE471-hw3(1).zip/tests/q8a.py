test = {   'name': 'q8a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> rmse(np.array([77]), '
                                               'np.array([7])) # RMSE of one '
                                               'data point\n'
                                               '70.0',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'np.isclose(rmse(np.arange(0, '
                                               '10), np.arange(10, 29, 2)), '
                                               '14.7817, rtol=0.1) # RMSE of '
                                               'multiple data points\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
