test = {   'name': 'q8c',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> test_error_difference >= '
                                               '0\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> '
                                               'np.isclose(test_error_difference, '
                                               '2477.00846, atol=0.1) or '
                                               'np.isclose(test_error_difference, '
                                               '2039.10204, atol=0.1) # 1st '
                                               'case correct, 2nd case if '
                                               'switched root & mean in rmse '
                                               "(our public tests didn't "
                                               'verify)\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
