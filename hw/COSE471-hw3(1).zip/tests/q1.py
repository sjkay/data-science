test = {   'name': 'q1',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> set([q1statement1, '
                                               'q1statement2, '
                                               'q1statement3]).issubset({False, '
                                               'True})\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> q1statement1\nFalse',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> q1statement1\nFalse',
                                       'hidden': True,
                                       'locked': False},
                                   {   'code': '>>> q1statement3\nTrue',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
