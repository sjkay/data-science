test = {   'name': 'q2b',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> A.shape\n(3, 4)',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.allclose(A @ B @ v , '
                                               'np.array([ 46,  86, 400]))\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
