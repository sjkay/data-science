test = {   'name': 'q2a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> B.shape\n(4, 3)',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.allclose(B @ v, '
                                               'np.array([14, 18, 14, 40]))\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
