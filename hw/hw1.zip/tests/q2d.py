test = {   'name': 'q2d',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> new_v.shape\n(3,)',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> np.allclose(new_v, '
                                               'np.array([ 5.5,  2.20833333,  '
                                               '1.]))\n'
                                               'True',
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
