test = {   'name': 'q7e',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 < proportion_trump < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(proportion_trump - 0.695) <= 0.02\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}