test = {   'name': 'q6b',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> p_majority >= 0 and p_majority <= 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}


