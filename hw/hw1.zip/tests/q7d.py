test = {   'name': 'q7d',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> trump_wins(1000) in [0, 1]\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}