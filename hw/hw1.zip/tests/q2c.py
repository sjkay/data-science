test = {   'name': 'q2c',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> most in ["Joey", "Deb", '
                                               '"Sam"]\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> most\n'Sam'",
                                       'hidden': True,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
