test = {   'name': 'q7b',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> assert -1 < trump_advantage(draw_state_sample(1500, "wisconsin")) < 1;\n'
                                               '>>> assert np.isclose(trump_advantage([100, 60, 40]), 0.2);\n'
                                               '>>> assert np.isclose(trump_advantage([10, 30, 10]), -0.4)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}