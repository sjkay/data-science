test = {   'name': 'q6a',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> prob_at_most(3, 0.4, 1) >= 0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> prob_at_most(5, 0.6, 3) <= 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> prob_at_most(2, 3, 4) == 0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
