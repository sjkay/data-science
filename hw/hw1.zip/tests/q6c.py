test = {   'name': 'q6c',
    'points': 2,
    'suites': [{'cases': [{'code': '>>> prob_6c >= 0 and prob_6c <= 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}

