test = {   'name': 'q5a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               "np.isclose(trump.loc[690171032150237184]['hour'], "
                                               '8.93639)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
