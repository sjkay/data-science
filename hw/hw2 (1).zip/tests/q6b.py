test = {   'name': 'q6b',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> '
                                               "trump['text'].loc[884740553040175104] "
                                               "== 'working hard to get the "
                                               'olympics for the united states '
                                               "(l.a.). stay tuned!'\n"
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
